// class IOUnit {
//     constructor(buffer) {
//     this.buffer = buffer;
//     }
//     getBuffer() {
//     return this.buffer;
//     }
//     setBuffer(buffer) {
//     this.buffer = buffer;
//     }
//     write() {
//     console.log(this.buffer);
//     }
// }
// export default IOUnit;
class IOUnit {
    constructor() {
        // Buffer: 4 registers, each holding 2 bytes (total 8 bytes)
        this.buffer = new Uint8Array(8);

        // I/O Controller: Manages data transfer and communication
        this.ioController = {
            busy: false,  // Indicates if an I/O operation is in progress
            sequencerSignal: null,  // Signal from sequencer
            ioInterfaceSignal: null // Signal from I/O interface
        };
    }

    // Write data to a specific register (index 0-3)
    writeToRegister(registerIndex, lowByte, highByte) {
        if (registerIndex < 0 || registerIndex >= 4) {
            throw new Error("Invalid register index");
        }
        this.buffer[registerIndex * 2] = lowByte & 0xFF;   // Store lower byte
        this.buffer[registerIndex * 2 + 1] = highByte & 0xFF; // Store higher byte
        this.ioController.busy = true; // Mark transfer as active
    }

    // Read data from a specific register (index 0-3)
    readFromRegister(registerIndex) {
        if (registerIndex < 0 || registerIndex >= 4) {
            throw new Error("Invalid register index");
        }
        return [
            this.buffer[registerIndex * 2],     // Low byte
            this.buffer[registerIndex * 2 + 1]  // High byte
        ];
    }

    // Handles communication with the sequencer
    communicateWithSequencer(signal) {
        this.ioController.sequencerSignal = signal;
    }

    // Handles communication with I/O interface
    communicateWithIOInterface(signal) {
        this.ioController.ioInterfaceSignal = signal;
    }
}

export default IOUnit;
